# Gateway — Caddy + ngrok (1 domain → nhiều app)

Hạ tầng dùng chung để expose **nhiều app local ra Internet qua MỘT domain ngrok free**
(ngrok free chỉ cho 1 domain + 1 tunnel online). Một **Caddy** reverse-proxy đứng trước, route
theo path prefix; **một ngrok** trỏ vào Caddy.

```
ngrok ─→ Caddy :PROXY_PORT(8080) ─┬─ /ai, /ai/*  → chatwork ui-next   127.0.0.1:AI_PORT(5000)
                                  ├─ /shop/*      → (app sau)          ...
                                  └─ /*           → elearning          127.0.0.1:ELEARNING_PORT(4000)
```

Dir này **không phải app** — chỉ proxy. Mỗi app chạy Next riêng trên port riêng, tự đặt `basePath`.

## 1. Cài Caddy (chọn 1 cách)

**Cách A — apt (repo chính thức, cần sudo):**
```bash
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
  | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
  | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update && sudo apt install caddy
caddy version          # → /usr/bin/caddy (trên PATH)
```

**Cách B — binary tĩnh, không cần sudo:**
```bash
mkdir -p ~/.local/bin
curl -fsSL "https://caddyserver.com/api/download?os=linux&arch=amd64" -o ~/.local/bin/caddy
chmod +x ~/.local/bin/caddy
caddy version
```
> Nếu pm2 không thấy `caddy` trên PATH → đặt `CADDY_BIN` trong `.env`
> (`/usr/bin/caddy` hoặc `$HOME/.local/bin/caddy`).

## 2. Chạy gateway

```bash
cd ~/IdeaProjects/gateway
cp .env.example .env            # sửa NGROK_DOMAIN + các *_PORT cho khớp app thật
pm2 start ecosystem.config.js   # caddy-gateway + ngrok-gateway
pm2 logs caddy-gateway          # kiểm tra lắng nghe :8080
pm2 save                        # giữ qua reboot
```
- Mỗi app phải tự chạy (pm2 riêng) trên đúng port khai trong `.env`.
- ngrok dùng `--url=$NGROK_DOMAIN` → **gỡ mọi ngrok riêng trong từng app** để khỏi tranh domain.

Truy cập: `https://<NGROK_DOMAIN>/ai` → chatwork · `https://<NGROK_DOMAIN>/` → elearning.

## 3. Thêm app mới (vd `/shop`)

1. **App**: chạy Next trên 1 port mới (vd 5100), đặt `basePath=/shop`, và prefix mọi
   `fetch`/`EventSource` bằng basePath (Next không tự prefix mấy cái đó). Build lại.
2. **Gateway `.env`**: thêm `SHOP_PORT=5100`.
3. **`Caddyfile`**: bỏ comment / thêm khối:
   ```
   @shop path /shop /shop/*
   handle @shop { reverse_proxy 127.0.0.1:{$SHOP_PORT:5100} }
   ```
   (đặt TRƯỚC khối `handle` catch-all `/*`).
4. `pm2 restart ecosystem.config.js --update-env`.

## 4. Lưu ý

- **basePath baked lúc build** của mỗi app — đổi prefix phải build lại app đó.
- App phục vụ root `/*` (elearning) không cần basePath; chỉ một app được làm catch-all.
- Caddy stream SSE tốt (không buffer `text/event-stream`) → tiến trình agent vẫn live.
- Đây là proxy **dev/ngrok** (HTTP nội bộ, ngrok lo TLS). Production HTTPS của từng app là việc
  riêng của app đó (vd elearning có `Caddyfile` + `DEPLOY.md` riêng — KHÔNG liên quan file này).
