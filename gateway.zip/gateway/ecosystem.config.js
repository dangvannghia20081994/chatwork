// PM2 ecosystem for the SHARED GATEWAY: 1 Caddy (reverse proxy) + 1 ngrok tunnel.
// One free ngrok domain hosts many local apps, routed by path prefix (see Caddyfile).
// This dir is NOT an app — it only proxies. Each app runs its own Next on its own port.
//
//   cd ~/IdeaProjects/gateway && pm2 start ecosystem.config.js   # caddy + ngrok
//   pm2 logs caddy-gateway | ngrok-gateway
//   pm2 restart ecosystem.config.js --update-env                 # sau khi sửa .env
//   pm2 save && pm2 startup
//
// Cài Caddy trước (xem README). Config trong ./.env: PROXY_PORT, NGROK_DOMAIN, CADDY_BIN, *_PORT.

const fs = require("fs");
const path = require("path");

// Nạp ./.env vào process.env (không cần dotenv — dir này không có node_modules). Soft-fail nếu thiếu.
// Để Caddyfile {$VAR} và ngrok đọc được PROXY_PORT / NGROK_DOMAIN / *_PORT từ một chỗ.
try {
  for (const raw of fs.readFileSync(path.join(__dirname, ".env"), "utf8").split("\n")) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)$/.exec(raw.replace(/\r$/, ""));
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].trim().replace(/^["']|["']$/g, "");
  }
} catch {}

const PROXY_PORT = process.env.PROXY_PORT || "8080";
const NGROK_DOMAIN = process.env.NGROK_DOMAIN || "these-cadet-unaired.ngrok-free.dev";

module.exports = {
  apps: [
    {
      // Reverse proxy. Caddyfile reads {$*_PORT} from this process env (inherited via ...process.env).
      name: "caddy-gateway",
      script: process.env.CADDY_BIN || "caddy",
      args: `run --config ${path.join(__dirname, "Caddyfile")} --adapter caddyfile`,
      interpreter: "none",
      cwd: __dirname,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      env: {
        ...process.env,
        PROXY_PORT,
        PATH: `${process.env.HOME}/.local/bin:${process.env.PATH || ""}`,
      },
      out_file: path.join(__dirname, "logs/caddy-out.log"),
      error_file: path.join(__dirname, "logs/caddy-error.log"),
      merge_logs: true,
      time: true,
    },
    {
      // Single ngrok tunnel → the proxy (fronts every app).
      name: "ngrok-gateway",
      script: "/usr/local/bin/ngrok",
      args: `http --url=${NGROK_DOMAIN} ${PROXY_PORT}`,
      interpreter: "none",
      cwd: __dirname,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      out_file: path.join(__dirname, "logs/ngrok-out.log"),
      error_file: path.join(__dirname, "logs/ngrok-error.log"),
      merge_logs: true,
      time: true,
    },
  ],
};
